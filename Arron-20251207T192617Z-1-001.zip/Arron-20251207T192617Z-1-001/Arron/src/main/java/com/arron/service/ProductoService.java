package com.arron.service;

import com.arron.model.Producto;
import com.arron.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository repo;

    public List<Producto> listar() {
        return repo.findAll();
    }

    public void guardar(Producto producto) {
        repo.save(producto);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
