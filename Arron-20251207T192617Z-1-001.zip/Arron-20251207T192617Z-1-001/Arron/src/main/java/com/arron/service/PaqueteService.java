package com.arron.service;

import com.arron.model.Paquete;
import com.arron.repository.PaqueteRepository;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class PaqueteService {

    @Autowired
    private PaqueteRepository repo;

    public List<Paquete> listar() {
        return repo.findAll();
    }

    public void guardar(Paquete paquete) {
        repo.save(paquete);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
