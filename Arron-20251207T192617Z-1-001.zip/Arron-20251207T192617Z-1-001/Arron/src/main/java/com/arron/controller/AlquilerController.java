package com.arron.controller;

import com.arron.service.AlquilerService;
import com.arron.repository.DetalleContieneRepository;
import com.arron.repository.DetalleServicioRepository;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/alquiler")
public class AlquilerController {

    @Autowired
    private AlquilerService service;

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("alquileres", service.listar());
        return "Alquiler";
    }
    @Autowired
    private DetalleContieneRepository detallesRepo;

    @Autowired
    private DetalleServicioRepository detalleServicioRepo;

    @GetMapping("/detalle/{id}")
    public String detalle(@PathVariable Long id, Model model) {
        model.addAttribute("alquiler", service.buscar(id));
        model.addAttribute("productos", detallesRepo.findByIdAlquiler(id));
        model.addAttribute("servicios", detalleServicioRepo.findByIdAlquiler(id));
        return "AlquilerDetalle";
    }

}
