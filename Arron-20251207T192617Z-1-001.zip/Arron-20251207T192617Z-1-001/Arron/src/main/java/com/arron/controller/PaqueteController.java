package com.arron.controller;

import com.arron.model.Paquete;
import com.arron.service.PaqueteService;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

@Controller
@RequestMapping("/paquetes")
public class PaqueteController {

    @Autowired
    private PaqueteService service;

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("paquetes", service.listar());
        return "Paquetes";
    }

    @PostMapping("/guardar")
    public String guardar(Paquete paquete) {
        service.guardar(paquete);
        return "redirect:/paquetes";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "redirect:/paquetes";
    }
}
