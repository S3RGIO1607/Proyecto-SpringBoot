package com.arron.controller;

import com.arron.model.Producto;
import com.arron.service.ProductoService;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/producto")
public class ProductoController {

    @Autowired
    private ProductoService service;

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("productos", service.listar());
        return "Producto";
    }

    @PostMapping("/guardar")
    public String guardar(Producto producto) {
        service.guardar(producto);
        return "redirect:/producto";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "redirect:/producto";
    }
}
