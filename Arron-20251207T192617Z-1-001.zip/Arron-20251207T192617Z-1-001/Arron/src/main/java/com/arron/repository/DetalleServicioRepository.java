package com.arron.repository;

import com.arron.model.DetalleServicio;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DetalleServicioRepository extends JpaRepository<DetalleServicio, Long> {

    List<DetalleServicio> findByIdAlquiler(Long idAlquiler);

}
