package com.arron.controller;

import com.arron.model.Servicio;
import com.arron.service.ServicioService;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/servicios")
public class ServicioController {

    @Autowired
    private ServicioService service;

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("servicios", service.listar());
        return "Servicios";
    }

    @PostMapping("/guardar")
    public String guardar(Servicio servicio) {
        service.guardar(servicio);
        return "redirect:/servicios";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "redirect:/servicios";
    }
}
