package com.arron.model;

import jakarta.persistence.*;

@Entity
@Table(name = "detalles_contiene")
public class DetalleContiene {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_alquiler")
    private Long idAlquiler;

    @Column(name = "id_producto")
    private Long idProducto;

    @Column(name = "cantidad_producto")
    private int cantidadProducto;

    @Column(name = "valor_producto_alquiler")
    private double valorProductoAlquiler;

    private String descripcion;
}
