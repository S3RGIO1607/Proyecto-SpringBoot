package com.arron.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "producto")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto")
    private Long idProducto;

    @Column(name = "nombre_producto")
    private String nombreProducto;

    @Column(name = "existencia")
    private int existencia;

    private String descripcion;

    @Column(name = "precio_compra")
    private double precioCompra;

    @Column(name = "precio_alquiler")
    private double precioAlquiler;

    @Column(name = "fecha_entrada")
    private Date fechaEntrada;

    @Column(name = "fecha_salida")
    private Date fechaSalida;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] imagen;

    @Column(name = "id_usuario")
    private Long idUsuario;

    // ==== GETTERS Y SETTERS ====
    // Genera getters y setters
}
