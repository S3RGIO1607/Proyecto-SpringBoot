package com.arron.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "alquiler")
public class Alquiler {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_alquiler")
    private Long idAlquiler;

    @Column(name = "fecha_evento")
    private Date fechaEvento;

    private double abono;
    private double saldo;

    @Column(name = "valor_total")
    private double valorTotal;

    @Column(name = "fecha_devolucion")
    private Date fechaDevolucion;

    @Column(name = "id_paquete")
    private Long idPaquete;

    @Column(name = "id_usuario")
    private Long idUsuario;

    // GETTERS Y SETTERS
}
