package com.arron.model;

import jakarta.persistence.*;

@Entity
@Table(name = "paquete")
public class Paquete {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_paquete")
    private Long idPaquete;

    @Column(name = "tipo_evento")
    private String tipoEvento;

    private String nombre;
    private String descripcion;

    @Column(name = "capacidad")
    private String capacidad;

    private double precio;

    // GETTERS Y SETTERS
}
