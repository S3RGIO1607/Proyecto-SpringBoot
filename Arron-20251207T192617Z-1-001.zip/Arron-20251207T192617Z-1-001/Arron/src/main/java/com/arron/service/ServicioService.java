package com.arron.service;

import com.arron.model.Servicio;
import com.arron.repository.ServicioRepository;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class ServicioService {

    @Autowired
    private ServicioRepository repo;

    public List<Servicio> listar() {
        return repo.findAll();
    }

    public void guardar(Servicio servicio) {
        repo.save(servicio);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
