package com.arron.repository;

import com.arron.model.DetalleContiene;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DetalleContieneRepository extends JpaRepository<DetalleContiene, Long> {

    List<DetalleContiene> findByIdAlquiler(Long idAlquiler);

}
