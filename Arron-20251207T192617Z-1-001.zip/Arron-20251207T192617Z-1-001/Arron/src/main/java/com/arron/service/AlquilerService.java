package com.arron.service;

import com.arron.model.Alquiler;
import com.arron.repository.AlquilerRepository;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class AlquilerService {

    @Autowired
    private AlquilerRepository repo;

    public List<Alquiler> listar() {
        return repo.findAll();
    }

    public Alquiler buscar(Long id) {
        return repo.findById(id).orElse(null);
    }
}
